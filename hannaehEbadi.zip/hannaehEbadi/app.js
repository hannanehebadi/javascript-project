const contentElement = document.querySelector("#content");
const inputElement = document.querySelector("#toDoValue");
const list = document.querySelector("#elements");
const submitElement = document.querySelector("#addTask");

contentElement.addEventListener("submit", function (e) {
  e.preventDefault();
  let inputValue = inputElement.value;
  let liElement = document.createElement("li");
  const deleteElement = document.createElement("div");
  const doneElement = document.createElement("div");
  const editElement = document.createElement("div");
  deleteElement.innerHTML = `<button id='delete'>delete</button>`;
  doneElement.innerHTML = `<button id='done'>done</button>`;
  editElement.innerHTML = `<button id='edit'>edit</button>`;
  liElement.innerText = inputValue;
  list.append(liElement);
  inputElement.value = "";
  liElement.append(deleteElement, doneElement, editElement);
  deleteElement.addEventListener("click", function () {
    liElement.remove();
  });

  doneElement.addEventListener("click", function () {
    const deleteInDoneElement = document.createElement("div");
    const undoElement = document.createElement("div");
    deleteInDoneElement.innerHTML = `<button id='deleteInDone'>delete</button>`;
    undoElement.innerHTML = `<button id='undo'>undo</button>`;

    const doneItemsElement = document.getElementById("doneItems");
    doneItemsElement.innerHTML += `<li>${inputValue}</li>`;
    doneItemsElement.append(deleteInDoneElement, undoElement);
    liElement.remove();

    deleteInDoneElement.addEventListener("click", (e) => {
      e.preventDefault();
      doneItemsElement.remove();
    });

    undoElement.addEventListener("click", () => {
      const toDoItemsElement = document.getElementById("elements");
      const solveToDo =
        (toDoItemsElement.innerHTML += `<li>${inputValue}</li>`);
      list.append(deleteElement, doneElement, editElement);
      doneItemsElement.remove();
    });
  });
});
